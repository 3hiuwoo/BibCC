"""
BibTeX Completer — fill missing metadata fields from the venue library.

Each journal article or conference paper is matched against the venue
library (the user library merged with the project's ``.bibcc-venues.yaml``,
see :mod:`bibcc.venues`).
Fields the entry lacks are added; fields that differ are reported as
conflicts (in every mode, and in ``.bibcc/<input>/conflicts.txt``) and never
overwritten, unless ``--resolve library`` takes the library's value (narrow
the entries and fields it touches with ``--ids`` and ``--fields``).  The
library is the only source of added fields.

An entry whose booktitle is the interim name of a library record (the CVF
Open Access or OpenReview booktitle of proceedings that are now published
under another name) only receives the fields describing the event (venue
and month), and is reported so ``bibcc upgrade`` can replace it.

Workflow for venues missing from the library:
1. ``bibcc complete refs.bib`` writes ``.bibcc/refs.bib/missing_venues.yaml``
   with fields pre-filled from the bib entries, the previous edition of the
   same conference, and venue-name guesses (see :mod:`bibcc.missing_venues`).
   With ``--online`` CrossRef fills more fields, and every entry with a DOI
   is checked against CrossRef (see :mod:`bibcc.crosscheck`).
2. Fill in the remaining fields in that YAML file.
3. ``bibcc complete refs.bib --output out.bib --update-venues`` merges the
   YAML into the user library (``--scope project``: the project library) and
   completes with the updated library.
"""

from __future__ import annotations

import argparse
import re
import sys
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Mapping, Optional, Tuple

import bibtexparser
from bibtexparser.latexenc import latex_to_unicode

from bibcc.bibedit import (
    BibEditError,
    month_macro,
    read_bib,
    remove_fields,
    retype_entries,
    set_fields,
    unified_diff,
    write_bib,
)
from bibcc.crosscheck import Check, CrossrefCache, check_entry, entry_doi, venue_fields_from_crossref
from bibcc.helptext import ENV_VENUES, SCOPE_HELP, VENUES_HELP, HelpFormatter, epilog
from bibcc.logging_utils import Logger, remove_report, report_dir, write_report
from bibcc.missing_venues import (
    JOURNAL_FIELDS,
    PROCEEDINGS_FIELDS,
    MissingVenue,
    Suggestion,
    update_command,
    write_missing_venues,
)
from bibcc.venues import (
    EVENT_FIELDS,
    JOURNAL,
    NO_MONTH,
    PROJECT_SCOPE,
    SCOPES,
    USER_SCOPE,
    LibraryNotFound,
    Venue,
    VenueLibrary,
    is_conference_journal,
    is_no_month,
    load_library,
    merge_missing_venues,
    normalize_issn,
    normalize_venue,
    open_library,
    venue_kind,
)


def normalize_text(text: Optional[str]) -> str:
    """Normalize text for comparison by removing braces and lowercasing."""
    if not text:
        return ""
    return text.replace("{", "").replace("}", "").strip().lower()


def _comparable(name: str, value: Optional[str]) -> Any:
    """Reduce a field value to what matters when comparing it with the library."""
    if not value:
        return ""
    if name == "issn":
        return frozenset(normalize_issn(value)) or normalize_text(value)
    if name == "isbn":
        return frozenset(re.sub(r"[^0-9X]", "", part.upper()) for part in value.split(",") if part.strip())
    # bibtexparser's converter keeps the space that ends a control word (`\l czyk`)
    # and mangles an unbraced accent argument (`{\'n}`), so spell both the braced way.
    value = re.sub(r"\\([A-Za-z]+) +", r"{\\\1}", value)
    value = re.sub(r"\\(['\"`^~=.])([A-Za-z])", r"\\\1{\2}", value)
    text = latex_to_unicode(value).replace("{", "").replace("}", "")
    return " ".join(text.split()).casefold()


def same_field_value(name: str, existing: Optional[str], library: Optional[str]) -> bool:
    """Whether an entry's field agrees with the library value.

    Braces, case, whitespace, and LaTeX accents (``\\"{a}`` vs ``ä``) are
    ignored; ISBNs and ISSNs compare by their digits, months by macro.
    """
    if name == "month" and month_macro(library) and month_macro(existing) == month_macro(library):
        return True
    return _comparable(name, existing) == _comparable(name, library)


@dataclass
class EntryCompletion:
    """What the venue library says about one entry."""

    status: str  # "matched", "ambiguous", "missing", or "incomplete"
    kind: str = ""
    venue: Optional[Venue] = None
    patch: Dict[str, str] = field(default_factory=dict)
    # (field, existing value, library value)
    conflicts: List[Tuple[str, str, str]] = field(default_factory=list)
    # Set when the booktitle is an interim name ("cvf", "openreview") of ``venue``.
    interim_source: Optional[str] = None
    ambiguous: List[Venue] = field(default_factory=list)


def _origin_label(origin: str) -> str:
    """Log wording for the library a record's fields come from."""
    if origin == PROJECT_SCOPE:
        return "from the project library"
    if origin == "user+project":
        return "from the user and project libraries"
    return "from the user library"


def complete_entry(entry: Mapping[str, str], library: VenueLibrary) -> EntryCompletion:
    """Match one parsed entry against *library* and compute what to add.

    Missing fields are added, differing ones become conflicts, and an entry
    matched through an interim booktitle only gets :data:`EVENT_FIELDS`.
    A proceedings record also supplies the fields of its family record.
    """
    year = entry.get("year", "")
    venue_raw = entry.get("booktitle") or entry.get("journal") or ""
    kind = venue_kind(entry.get("ENTRYTYPE", ""), entry)
    if not year or not venue_raw:
        return EntryCompletion("incomplete", kind)
    result = library.lookup(venue_raw, year, kind, issn=entry.get("issn"))
    if result.ambiguous:
        return EntryCompletion("ambiguous", kind, ambiguous=result.ambiguous)
    if result.venue is None:
        return EntryCompletion("missing", kind)

    done = EntryCompletion("matched", kind, venue=result.venue, interim_source=result.interim_source)
    # A family record's fields apply to each of its editions, under the edition's own,
    # and the fields of the entry's book (an LNCS volume) over both.
    for name, value in library.entry_fields_of(result.venue, entry).items():
        if result.interim_source and name not in EVENT_FIELDS:
            continue
        if is_no_month(name, value):
            if str(entry.get(name, "")).strip():
                done.conflicts.append((name, entry.get(name, ""), value))
            continue
        if name not in entry:
            done.patch[name] = value
        elif not same_field_value(name, entry.get(name, ""), value):
            done.conflicts.append((name, entry.get(name, ""), value))
    return done


def compute_completion(
    entries: List[Dict[str, Any]],
    library: VenueLibrary,
) -> Dict[str, Any]:
    """Match entries against the library and compute what to add.

    Returns a dict with:
      - ``patches``:    ``{entry_id: {field: value}}`` fields to add
      - ``conflicts``:  ``{entry_id: [(field, existing, library_value)]}``
      - ``ambiguous``:  ``[(entry_id, venue, [labels])]`` several records matched
      - ``interim``:    ``[(entry_id, booktitle, source, Venue)]`` interim booktitles
      - ``matched``:    ``{entry_id: Venue}`` the record each entry matched
      - ``missing``:    ``{(norm_venue, year): (venue, year, type)}`` not in library
      - ``missing_entries``: ``{(norm_venue, year): [entry_id]}``
      - ``collected``:  ``{key: {field: most common value}}`` for pre-filling
      - ``collected_from``: ``{key: {field: [entry_id]}}`` the entries each
        collected value comes from
      - ``incomplete``: ``[(entry_id, venue, year, entry_type)]`` entries lacking venue/year
    """
    out: Dict[str, Any] = {
        "patches": {}, "conflicts": {}, "ambiguous": [], "interim": [], "matched": {},
        "missing": {}, "missing_entries": {}, "incomplete": [], "collected_from": {},
    }
    counters: Dict[Tuple[str, str], Dict[str, Counter]] = {}
    contributors: Dict[Tuple[str, str], Dict[str, Dict[str, List[str]]]] = {}

    for entry in entries:
        entry_id = entry["ID"]
        year = entry.get("year", "")
        venue_raw = entry.get("booktitle") or entry.get("journal") or ""
        done = complete_entry(entry, library)

        if done.status == "incomplete":
            out["incomplete"].append((entry_id, venue_raw, year, entry.get("ENTRYTYPE", "")))
        elif done.status == "ambiguous":
            out["ambiguous"].append((entry_id, venue_raw, [v.label for v in done.ambiguous]))
        elif done.status == "missing":
            key = (normalize_venue(venue_raw), "" if done.kind == JOURNAL else normalize_text(year))
            out["missing"].setdefault(key, (venue_raw, year, done.kind))
            out["missing_entries"].setdefault(key, []).append(entry_id)
            entry_counters = counters.setdefault(key, {})
            entry_contributors = contributors.setdefault(key, {})
            for fname in JOURNAL_FIELDS if done.kind == JOURNAL else PROCEEDINGS_FIELDS:
                val = entry.get(fname, "").strip()
                if val:
                    entry_counters.setdefault(fname, Counter())[val] += 1
                    entry_contributors.setdefault(fname, {}).setdefault(val, []).append(entry_id)
        else:
            out["matched"][entry_id] = done.venue
            if done.patch:
                out["patches"][entry_id] = done.patch
            if done.conflicts:
                out["conflicts"][entry_id] = done.conflicts
            if done.interim_source:
                out["interim"].append((entry_id, venue_raw, done.interim_source, done.venue))

    out["collected"] = {
        key: {fname: counter.most_common(1)[0][0] for fname, counter in field_counters.items()}
        for key, field_counters in counters.items()
    }
    out["collected_from"] = {
        key: {
            fname: contributors[key].get(fname, {}).get(value, [])
            for fname, value in fields.items()
        }
        for key, fields in out["collected"].items()
    }
    return out


def retype_conference_articles(text: str, only_ids: Optional[List[str]] = None) -> Tuple[str, List[Tuple[str, str]]]:
    """Make the ``@article`` entries for conference proceedings ``@inproceedings``.

    AAAI exports its papers as ``@article`` with the proceedings name as the
    ``journal``; the name becomes the ``booktitle``.  Returns the new text
    and ``(entry_id, journal)`` for each entry changed.
    """
    parser = bibtexparser.bparser.BibTexParser(common_strings=True)
    changes: Dict[str, Tuple[str, Dict[str, str]]] = {}
    found: List[Tuple[str, str]] = []
    for entry in bibtexparser.loads(text, parser=parser).entries:
        if only_ids is not None and entry["ID"] not in only_ids:
            continue
        journal = entry.get("journal", "")
        if entry.get("ENTRYTYPE") == "article" and "booktitle" not in entry and is_conference_journal(journal):
            changes[entry["ID"]] = ("inproceedings", {"journal": "booktitle"})
            found.append((entry["ID"], journal))
    if not changes:
        return text, []
    return retype_entries(text, changes), found


def _online_checks(
    entries: List[Dict[str, Any]],
    result: Dict[str, Any],
    cache: CrossrefCache,
    log: Callable[[str], None],
    library: Optional[VenueLibrary] = None,
) -> Tuple[List[Check], List[Tuple[str, str]], List[Suggestion], Dict[Tuple[str, str], Dict[str, str]]]:
    """Check entries against CrossRef; returns checks, unchecked entries, suggestions, and CrossRef fills."""
    by_id = {e["ID"]: e for e in entries}
    checks: List[Check] = []
    unchecked: List[Tuple[str, str]] = []
    library_votes: Dict[Tuple[int, str], Dict[str, List[str]]] = {}
    venues_by_id: Dict[int, Venue] = {}

    with_doi = [e for e in entries if entry_doi(e)]
    log(f"\n🌐 Checking {len(with_doi)} entries with a DOI against CrossRef...")
    for entry in entries:
        key = entry["ID"]
        doi = entry_doi(entry)
        if not doi:
            unchecked.append((key, "no DOI"))
            continue
        record, error = cache.get(doi)
        if record is None:
            unchecked.append((key, f"CrossRef: {error or 'no record'}"))
            continue
        venue = result["matched"].get(key)
        kind = venue_kind(entry.get("ENTRYTYPE", ""), entry)
        fields = library.fields_of(venue) if library is not None and venue is not None else None
        for check in check_entry(key, entry, kind, venue, record, fields):
            checks.append(check)
            if venue is not None and check.verdict in ("library differs", "bib and library differ") \
                    and check.name not in ("journal", "booktitle"):
                venues_by_id[id(venue)] = venue
                votes = library_votes.setdefault((id(venue), check.name), {})
                votes.setdefault(check.crossref.split(" | ")[0], []).append(f"{key} ({doi})")

    suggestions = []
    for (venue_id, name), votes in library_votes.items():
        if len(votes) != 1:
            continue  # CrossRef itself disagrees between papers of this venue
        value, keys = next(iter(votes.items()))
        evidence = f"CrossRef for {', '.join(keys[:3])}" + (f" and {len(keys) - 3} more" if len(keys) > 3 else "")
        suggestions.append(Suggestion(venues_by_id[venue_id], name, value, evidence))

    fills: Dict[Tuple[str, str], Dict[str, str]] = {}
    for key, ids in result["missing_entries"].items():
        kind = result["missing"][key][2]
        for entry_id in ids:
            record, _ = cache.get(entry_doi(by_id[entry_id]))
            if record is not None:
                fills[key] = venue_fields_from_crossref(record, kind)
                break
    return checks, unchecked, suggestions, fills


def main(
    input_path: str,
    output_path: str,
    dry_run: bool = False,
    log_dir: Path | None = None,
    library: Optional[VenueLibrary] = None,
    log: Optional[Callable[[str], None]] = None,
    online: bool = False,
    delay: float = 1.0,
    resolve: str = "keep",
    only_fields: Optional[List[str]] = None,
    only_ids: Optional[List[str]] = None,
):
    """Complete *input_path* and write the result to *output_path* unless *dry_run*.

    Only the added fields change in the output; everything else in the file
    is kept byte for byte.  With ``resolve="library"``, fields that differ
    from the library are overwritten with the library's values.  *only_ids*
    and *only_fields* narrow the entries and fields the command may add or
    overwrite; the reports still cover the whole file.  Reports (conflicts,
    missing venues, incomplete entries, and with *online* the CrossRef check)
    are written in every mode.  Raises :class:`BibEditError` (and writes
    nothing) if the edits cannot be applied safely.
    """
    log = log or print
    library = library if library is not None else load_library(start=input_path)
    log(f"Reading {input_path}...")
    log(f"📦 Venue library: {library.describe()}")

    original = read_bib(input_path)
    text, retyped = retype_conference_articles(original, only_ids)
    parser = bibtexparser.bparser.BibTexParser(common_strings=True)
    bib_db = bibtexparser.loads(text, parser=parser)

    result = compute_completion(bib_db.entries, library)
    patches = result["patches"]
    conflicts = result["conflicts"]
    ambiguous = result["ambiguous"]
    interim = result["interim"]
    missing = result["missing"]
    incomplete_entries = result["incomplete"]

    wanted_ids = set(only_ids) if only_ids is not None else None
    if wanted_ids is not None:
        unknown = sorted(wanted_ids - {e["ID"] for e in bib_db.entries})
        if unknown:
            log(f"⚠️  --ids: no entries with keys: {', '.join(unknown)}")
        patches = {eid: p for eid, p in patches.items() if eid in wanted_ids}
    wanted_fields = set(only_fields) if only_fields is not None else None
    if wanted_fields is not None:
        patches = {
            eid: p
            for eid, p in (
                (eid, {f: v for f, v in p.items() if f in wanted_fields})
                for eid, p in patches.items()
            )
            if p
        }

    # Conflicts the user asked to overwrite with the library values.  A record
    # that says the venue has no month removes the entry's month (and day).
    resolved: Dict[str, List[Tuple[str, str, str]]] = {}
    removals: Dict[str, List[str]] = {}
    if resolve == "library":
        for eid, rows in conflicts.items():
            if wanted_ids is not None and eid not in wanted_ids:
                continue
            for name, existing_val, library_val in rows:
                if wanted_fields is not None and name not in wanted_fields:
                    continue
                if is_no_month(name, library_val):
                    removals.setdefault(eid, []).extend([name, "day"])
                else:
                    patches.setdefault(eid, {})[name] = library_val
                resolved.setdefault(eid, []).append((name, existing_val, library_val))

    # Conflicts that stay as they are: all of them with --resolve keep, or
    # the ones that --ids or --fields leave out with --resolve library.
    leftover: Dict[str, List[Tuple[str, str, str]]] = {}
    for eid, rows in conflicts.items():
        done_fields = {name for name, _, _ in resolved.get(eid, [])}
        rest = [row for row in rows if row[0] not in done_fields]
        if rest:
            leftover[eid] = rest

    log(f"  Identified {len(patches)} entries to patch.")
    if patches and library.scope == "merged":
        log("\n📚 Library records the patches come from:")
        for eid in sorted(patches):
            venue = result["matched"].get(eid)
            if venue is not None:
                log(f"  🔸 {eid}: '{venue.label}' ({_origin_label(venue.origin)})")

    new_text, applied = set_fields(text, patches, replace=bool(resolved))
    if removals:
        new_text, removed = remove_fields(new_text, removals)
        applied += removed
    additions = [a for a in applied if a.action == "added"]
    overwrites = [a for a in applied if a.action in ("replaced", "removed")]
    if retyped:
        log("\n🔁 Conference papers exported as @article, now @inproceedings with the journal "
            "name as their booktitle:")
        for eid, journal in retyped:
            log(f"  🔸 {eid}: '{journal}'")

    output_dir = report_dir(input_path, log_dir)
    conflict_log = output_dir / "conflicts.txt"
    missing_txt_log = output_dir / "missing_venues.txt"
    missing_yaml_log = output_dir / "missing_venues.yaml"
    incomplete_log = output_dir / "incomplete_entries.txt"
    check_log = output_dir / "venue_check.txt"
    diff_log = output_dir / "complete.diff"

    checks: List[Check] = []
    unchecked: List[Tuple[str, str]] = []
    suggestions: List[Suggestion] = []
    fills: Dict[Tuple[str, str], Dict[str, str]] = {}
    if online:
        checks, unchecked, suggestions, fills = _online_checks(
            bib_db.entries, result, CrossrefCache(delay), log, library
        )

    conflict_rows: List[str] = []
    for eid, rows in conflicts.items():
        for k, existing_val, tmpl_val in rows:
            conflict_rows.append(f"{eid}\t{k}\tEXISTING={existing_val}\tLIBRARY={tmpl_val}")
    for eid, venue_raw, labels in ambiguous:
        conflict_rows.append(f"{eid}\t(venue)\tVENUE={venue_raw}\tAMBIGUOUS={' | '.join(labels)}")
    for eid, venue_raw, source, venue in interim:
        conflict_rows.append(
            f"{eid}\tbooktitle\tEXISTING={venue_raw}\tLIBRARY={venue.name}\t"
            f"({source} booktitle; run bibcc upgrade)"
        )

    missing_rows = [
        f"{v}\t{y}\t{t}\t{', '.join(result['missing_entries'].get(k, []))}"
        for k, (v, y, t) in missing.items()
    ]
    incomplete_rows = [
        f"{eid}\t{entry_type or '?'}\tvenue={venue or '(empty)'}\tyear={year or '(empty)'}"
        for eid, venue, year, entry_type in incomplete_entries
    ]

    if dry_run:
        diff = unified_diff(original, new_text, input_path)
        if diff:
            what = f"{len(additions)} fields to add"
            if retyped:
                what += f", {len(retyped)} entry types to change"
            if overwrites:
                what += f", {len(overwrites)} to overwrite with the library values"
            log(f"\n🧪 Dry-run preview ({what}):")
            log(diff.rstrip("\n"))
            diff_log.write_text(diff, encoding="utf-8")
        else:
            log("\n🧪 Dry run: no additions needed.")
            remove_report(diff_log)
    else:
        remove_report(diff_log)

    if conflicts:
        if resolved:
            log("\n🔁 Conflicts overwritten with the library values:")
            for eid, rows in resolved.items():
                log(f"Entry ID: {eid}")
                for k, existing_val, tmpl_val in rows:
                    if is_no_month(k, tmpl_val):
                        log(f"  field '{k}': '{existing_val}' removed (the venue has no month)")
                    else:
                        log(f"  field '{k}': '{existing_val}' → '{tmpl_val}'")
        if leftover:
            if resolved:
                log("\n⚠️  Conflicts left unchanged (not selected by --ids or --fields):")
            else:
                log("\n⚠️  Conflicts (existing value differs from library, not overwritten):")
            for eid, rows in leftover.items():
                log(f"Entry ID: {eid}")
                for k, existing_val, tmpl_val in rows:
                    log(f"  field '{k}': existing='{existing_val}', library='{tmpl_val}'")
            if not resolved:
                log("   To take the library values instead, rerun with --resolve library.")
            if any(is_no_month(k, v) for rows in leftover.values() for k, _, v in rows):
                log(f"   library='{NO_MONTH}' means that the venue has no month; --resolve library removes "
                    "the entry's month and day.")
    else:
        log("\n✅ No conflicts detected.")

    if interim:
        log("\n⏳ Interim booktitles (only venue and month added; the proceedings are out):")
        for eid, venue_raw, source, venue in interim:
            log(f"  🔸 {eid}: {source} name '{venue_raw}' → proceedings '{venue.name}'")
        log("   Run `bibcc upgrade` on this file to switch them to the proceedings' official BibTeX.")

    if ambiguous:
        log("\n⚠️  Ambiguous venues (several library records match, nothing added):")
        for eid, venue_raw, labels in ambiguous:
            log(f"  🔸 {eid}: '{venue_raw}' matches {', '.join(labels)}")

    to_fix = [row for row in incomplete_entries if row[3].lower() != "misc"]
    misc_skipped = [row for row in incomplete_entries if row[3].lower() == "misc"]
    if to_fix:
        log("\n📭 Incomplete entries (missing year or venue), not completed:")
        for entry_id, venue, year, entry_type in to_fix:
            log(f"  🔸 {entry_id} (@{entry_type or '?'}): venue='{venue or '(empty)'}' "
                f"year='{year or '(empty)'}'")
    if misc_skipped:
        keys = ", ".join(row[0] for row in misc_skipped)
        log(f"\nℹ️  Skipped {len(misc_skipped)} misc "
            f"{'entry' if len(misc_skipped) == 1 else 'entries'} (no venue expected): {keys}")

    if missing:
        log("\nℹ️  Venues not in the library (deduplicated):")
        for key, (venue_raw, year, entry_type) in missing.items():
            type_icon = "📰" if entry_type == JOURNAL else "📋"
            log(f"  {type_icon} [{entry_type}] venue='{venue_raw}' year='{year}'")
            ids = result["missing_entries"].get(key, [])
            if ids:
                log(f"     entries: {', '.join(ids)}")
            sources = [
                f"{fname} (from {', '.join(ids)})"
                for fname, ids in result["collected_from"].get(key, {}).items()
                if ids
            ]
            if sources:
                log(f"     pre-filled from entries: {'; '.join(sources)}")
    else:
        log("\n✅ All complete entries matched the venue library.")

    if online:
        differ = [c for c in checks if c.verdict != "ok"]
        log(f"\n🌐 CrossRef check: {len(checks) - len(differ)} fields agree, {len(differ)} differ, "
            f"{len(unchecked)} entries not checked.")
        for c in differ:
            log(f"  🔸 {c.key} {c.name}: {c.verdict} (bib='{c.bib}', library='{c.library}', "
                f"CrossRef='{c.crossref}')")
        check_rows = [
            f"{c.key}\t{c.name}\t{c.verdict}\tBIB={c.bib}\tLIBRARY={c.library}\tCROSSREF={c.crossref}"
            for c in differ
        ]
        check_rows += [f"{key}\t(not checked)\t{why}" for key, why in unchecked]
        write_report(check_log, "venue check: entry_id\tfield\tverdict\tbib\tlibrary\tcrossref", check_rows)

    write_report(conflict_log, "conflicts: entry_id\tfield\texisting\tlibrary", conflict_rows)
    write_report(missing_txt_log, "missing venues: venue\tyear\ttype\tentries", missing_rows)
    write_report(
        incomplete_log,
        "incomplete entries (missing year or venue): entry_id\ttype\tvenue\tyear",
        incomplete_rows,
    )

    proposals = [
        MissingVenue(kind, venue_raw, year, collected=result["collected"].get(key, {}),
                     collected_from=result["collected_from"].get(key, {}),
                     crossref=fills.get(key, {}),
                     entries=result["missing_entries"].get(key, []))
        for key, (venue_raw, year, kind) in missing.items()
    ]
    rerun = update_command(input_path)
    counts = write_missing_venues(missing_yaml_log, proposals, library, rerun, suggestions=suggestions)
    if missing or suggestions:
        log(f"\n📝 Missing venues YAML: {missing_yaml_log} ({counts['new']} new, {counts['kept']} kept)")
        if suggestions:
            log(f"   {len(suggestions)} suggested corrections to library records are at its end (commented out).")
        log(f"   Fill in the fields and run: {rerun}")

    saved = [conflict_log, missing_txt_log, incomplete_log] + ([check_log] if online else [])
    if dry_run:
        if diff:
            saved.append(diff_log)
        log(f"\nReports saved: {', '.join(str(p) for p in saved)}")
        log("💡 To write the changes, run with --output FILE.bib or --in-place.")
        return

    write_bib(output_path, new_text)
    entries_changed = len({a.key for a in applied} | {eid for eid, _ in retyped})
    if overwrites:
        log(f"\n✅ Added {len(additions)} fields and overwrote "
            f"{len(overwrites)} value{'s' * (len(overwrites) != 1)} "
            f"in {entries_changed} entries. Saved to {output_path}")
    else:
        log(f"\n✅ Added {len(additions)} fields to {entries_changed} entries. Saved to {output_path}")
    if leftover or ambiguous:
        log(f"⚠️  {len(leftover)} conflicting and {len(ambiguous)} ambiguous entries left unchanged.")
    log(f"Reports saved: {', '.join(str(p) for p in saved)}")


def build_parser() -> argparse.ArgumentParser:
    """Build argument parser for BibTeX completer."""
    parser = argparse.ArgumentParser(
        description="""\
Fill missing venue fields (such as publisher, ISSN, venue location, month,
ISBN, and series) in a .bib file from the venue library. Journals match by
name, alias, or ISSN; proceedings match by name or alias and the entry's
year.

The command never overwrites existing fields: it lists a different value as
a conflict (in every mode), unless you pass --resolve library, which takes
the library's value, for example after you fix a library record. --fields
and --ids narrow the fields and entries the command may add or overwrite;
the reports still cover the whole file. It inserts only the new fields, and
the rest of the file stays byte for byte. Without --output or --in-place,
the command does a dry run and writes the changes that it would make as a
diff.

If an entry's booktitle is the CVF Open Access or OpenReview name of
proceedings that the library knows by their published name, the entry gets
only the venue and month. The command lists the entry so that
'bibcc upgrade' can replace it.

The command writes venues that aren't in the library to a fill-in YAML file,
pre-filled from other entries of the same venue and from the previous
edition of a conference. Every run merges into this file instead of
overwriting it. Fill in the rest, and then rerun with --update-venues to add
the venues to the library and complete the file in one step, or with
--update-venues-only to only update the library and leave the file alone.

The library is your user library merged with the project's
.bibcc-venues.yaml (whose values win); see 'bibcc venues -h'. For each
entry it patches, the command logs the library the venue record comes
from. --update-venues and --update-venues-only write to the user library
unless you pass --scope project, and they log which file they write.

--online also queries CrossRef: it pre-fills more of the fill-in YAML, and it
compares each entry that has a DOI, and its library record, with CrossRef
(such as publisher, ISSN, ISBN, pages, and volume). The command only reports
the differences, and it suggests corrections to library records, commented
out, at the end of the YAML. Fields still come only from the library.""",
        epilog=epilog(
            examples=[
                ("Preview the changes (writes .bibcc/refs.bib/complete.diff)", "bibcc complete refs.bib"),
                ("Write the completed file elsewhere", "bibcc complete refs.bib --output out.bib"),
                ("Complete the file itself", "bibcc complete refs.bib --in-place"),
                ("After you fill in .bibcc/refs.bib/missing_venues.yaml, add those venues and complete",
                 "bibcc complete refs.bib --in-place --update-venues"),
                ("Only add the filled-in venues to the library, without touching the .bib file",
                 "bibcc complete refs.bib --update-venues-only"),
                ("Do the same, but add the venues to the project's .bibcc-venues.yaml",
                 "bibcc complete refs.bib --in-place --update-venues --scope project"),
                ("After fixing a library record, overwrite the fields it got wrong",
                 "bibcc complete refs.bib --in-place --resolve library --fields publisher,issn"),
                ("Also check the entries and the library against CrossRef", "bibcc complete refs.bib --online"),
            ],
            outputs=[
                (".bibcc/INPUT/complete.diff", "Dry run: the changes that the command would make"),
                (".bibcc/INPUT/missing_venues.yaml", "Fill-in records for venues that aren't in the library"),
                (".bibcc/INPUT/missing_venues.txt", "Entries whose venue isn't in the library"),
                (".bibcc/INPUT/conflicts.txt", "Fields that differ from the library, and interim booktitles"),
                (".bibcc/INPUT/incomplete_entries.txt", "Entries without a year or venue, with their entry type"),
                (".bibcc/INPUT/venue_check.txt", "--online: differences from CrossRef, and unchecked entries"),
                (".bibcc/INPUT/logs/completer.log", "Everything printed to the terminal"),
            ],
            exit_status="0 on success, 1 if BibCC can't verify the edits (it writes nothing), 2 on usage errors.",
            env=[ENV_VENUES],
        ),
        formatter_class=HelpFormatter,
    )
    parser.add_argument("input", type=str, help="The .bib file to complete.")
    parser.add_argument(
        "--output",
        type=str,
        default="",
        metavar="FILE",
        help="Write the completed file to FILE. For a dry run, omit both --output and --in-place.",
    )
    parser.add_argument(
        "--in-place",
        action="store_true",
        help="Write the completed entries back to the input file.",
    )
    parser.add_argument(
        "--log-dir",
        type=str,
        default="",
        metavar="DIR",
        help="Directory to use instead of .bibcc/ next to the input file; reports go to DIR/INPUT/.",
    )
    parser.add_argument(
        "--venues",
        type=str,
        default="",
        metavar="FILE",
        help=VENUES_HELP,
    )
    parser.add_argument(
        "--update-venues",
        "--update-templates",
        dest="update_venues",
        action="store_true",
        help="First merge the filled-in .bibcc/INPUT/missing_venues.yaml into the venue "
        "library that --scope selects (skipping records with no field filled in), and then "
        "complete the file.",
    )
    parser.add_argument(
        "--update-venues-only",
        action="store_true",
        help="Merge the filled-in .bibcc/INPUT/missing_venues.yaml into the venue library "
        "that --scope selects, and stop without completing the file.",
    )
    parser.add_argument(
        "--resolve",
        choices=["keep", "library"],
        default="keep",
        metavar="MODE",
        help="What to do when an entry's field differs from the library: 'keep' reports the "
        "conflict and leaves the entry alone (default); 'library' overwrites the entry's "
        "value with the library's, for example after you fix a library record.",
    )
    parser.add_argument(
        "--fields",
        type=str,
        default="",
        metavar="FIELDS",
        help="Comma-separated fields the command may add or overwrite (default: every field "
        "of the venue record). The reports still cover all fields.",
    )
    parser.add_argument(
        "--ids",
        type=str,
        default="",
        metavar="KEYS",
        help="Comma-separated citation keys to complete (default: all entries). The reports "
        "still cover the whole file.",
    )
    parser.add_argument("--scope", choices=SCOPES, default=None, help=SCOPE_HELP)
    parser.add_argument(
        "--online",
        action="store_true",
        help="Also query CrossRef: pre-fill the missing-venues YAML, and check entries with a "
        "DOI, and their library records, against CrossRef (report only; off by default).",
    )
    parser.add_argument(
        "--delay",
        type=float,
        default=1.0,
        metavar="SECONDS",
        help="With --online, seconds to wait between CrossRef requests (default: 1).",
    )
    return parser


def update_library(args: argparse.Namespace, log_dir: Optional[Path], log: Callable[[str], None]) -> None:
    """Merge the filled-in missing-venues YAML into the one library ``--venues``/``--scope`` names."""
    yaml_path = report_dir(args.input, log_dir) / "missing_venues.yaml"
    if not yaml_path.exists():
        log(f"ℹ️  No {yaml_path.name} found — run without --output first.")
        return
    try:
        target = open_library(args.scope or USER_SCOPE, venues=args.venues or None, start=args.input)
    except LibraryNotFound as e:
        log(f"❌ {e}")
        sys.exit(1)
    label = "library" if args.venues else f"{target.scope} library"
    log(f"🔄 Merging {yaml_path} into the {label} {target.path}...")
    counts = merge_missing_venues(target, yaml_path, log=log)
    if counts["added"] or counts["updated"]:
        target.save()
        log(
            f"✅ {label.capitalize()} updated ({target.path}): +{counts['added']} new, "
            f"~{counts['updated']} updated, {counts['skipped']} skipped.\n"
        )
    else:
        log("ℹ️  Nothing new to merge.\n")


def run(args: argparse.Namespace) -> None:
    """Run completer with parsed arguments."""
    if args.in_place and args.output:
        build_parser().error("use either --output or --in-place, not both")
    if args.scope and not (args.update_venues or args.update_venues_only):
        build_parser().error("--scope only applies with --update-venues or --update-venues-only")
    if args.scope and args.venues:
        build_parser().error("--venues already names the library to update; drop --scope")
    log_dir = Path(args.log_dir) if args.log_dir else None

    if args.update_venues_only:
        if args.output or args.in_place:
            build_parser().error(
                "--update-venues-only writes only the library; drop --output and --in-place"
            )
        if args.online or args.resolve != "keep" or args.fields or args.ids:
            build_parser().error(
                "--update-venues-only only merges the YAML file into the library; "
                "drop --online, --resolve, --fields, and --ids"
            )
        with Logger("completer", input_file=args.input, log_dir=log_dir) as logger:
            update_library(args, log_dir, logger.log)
        return

    output = args.input if args.in_place else args.output
    dry_run = not bool(output)

    with Logger("completer", input_file=args.input, log_dir=log_dir) as logger:
        if args.update_venues:
            update_library(args, log_dir, logger.log)
        library = load_library(args.venues or None, start=args.input)

        try:
            main(
                args.input,
                output or args.input,
                dry_run=dry_run,
                log_dir=log_dir,
                library=library,
                log=logger.log,
                online=args.online,
                delay=args.delay,
                resolve=args.resolve,
                only_fields=[f.strip().lower() for f in args.fields.split(",") if f.strip()] or None,
                only_ids=[i.strip() for i in args.ids.split(",") if i.strip()] or None,
            )
        except BibEditError as e:
            logger.log(f"❌ Could not apply the edits safely: {e}")
            logger.log("   Nothing was written.")
            sys.exit(1)


if __name__ == "__main__":
    parser = build_parser()
    args = parser.parse_args()
    run(args)
