"""
Reformat .bib files in a consistent, bibtex-tidy-like style.

The default style matches the survey bibliography::

    @inproceedings{GKEAL_Zhuang_CVPR2023,
      title     = {{GKEAL}: {Gaussian} Kernel ...},
      year      = {2023},
      month     = jun,
      booktitle = {2023 {IEEE/CVF} Conference ...}
    }

Entry types and field names are lowercased, ``=`` signs are aligned, values
are braced (``"..."`` and bare numbers) with one pair of braces (``{{...}}``
becomes ``{...}`` outside ``author``/``editor``), every field but the last
ends with a comma (missing ones are added), months become bare macros, page
ranges use ``--``, and entries are separated by one blank line.  Field values are otherwise copied
verbatim.  Text between entries (``%`` comments, ``@string``/``@comment``
blocks) is kept; only the blank lines around it are normalised.

Every result is re-parsed with bibtexparser and compared with the input:
the same entries, types, fields, and values (up to the conversions above).
If anything else differs, :class:`~bibcc.bibedit.BibEditError` is raised and
nothing is written.

By default nothing is written: the changes are saved as a diff under
``.bibcc/``.  Use ``--in-place`` or ``--output`` to write them, or
``--check`` to fail (exit 1) when a file is not formatted.

Usage:
    bibcc format refs.bib
    bibcc format bib/ --in-place
    bibcc format bib/ --check
"""

from __future__ import annotations

import argparse
import re
import sys
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional, Sequence, Set, Tuple

import bibtexparser
from bibtexparser.bibdatabase import BibDataString, BibDataStringExpression

from bibcc.adder import FIELD_ORDER
from bibcc.bibedit import (
    BibEditError,
    EntrySpan,
    balanced,
    month_macro,
    page_range,
    read_bib,
    scan,
    unified_diff,
    unwrap,
    value_tokens,
    write_bib,
)
from bibcc.config import (
    FORMAT_SECTION,
    FORMAT_SETTINGS,
    OTHER_FIELDS,
    PROJECT_CONFIG_NAME,
    USER_CONFIG_DISPLAY,
    Config,
    ConfigError,
    field_order_warnings,
    load_config,
    parse_field_order,
    parse_indent,
)
from bibcc.helptext import ENV_CONFIG, HelpFormatter, epilog
from bibcc.logging_utils import (
    OUTPUT_DIR_NAME,
    SEPARATOR_THIN,
    SEPARATOR_WIDTH,
    Logger,
    migrate_legacy_reports,
    remove_report,
    report_dir,
)

_BOM = "\ufeff"
_HOISTED_BLOCK = re.compile(r"^[ \t]*@\s*(string|preamble)\s*[{(]", re.IGNORECASE | re.MULTILINE)
# Double braces in name lists keep a corporate author ({{World Health Organization}}) as one name.
_NAME_FIELDS = frozenset({"author", "editor"})


@dataclass
class FormatOptions:
    """Style settings for :func:`format_text`."""

    sort_fields: bool = False
    # OTHER_FIELDS ("*") marks where unlisted fields go; without it they go last.
    field_order: Sequence[str] = tuple(FIELD_ORDER)
    sort_entries: bool = False
    braces: bool = True  # "..." and bare numbers become {...}
    outer_braces: bool = True  # {{...}} becomes {...} (except in name lists)
    months: bool = True  # month values become bare macros (jun)
    pages: bool = True  # page ranges use "--" (12-15 -> 12--15)
    align: bool = True
    indent: str = "  "
    blank_lines: int = 1
    trailing_comma: bool = False
    drop_empty: bool = False

    @classmethod
    def from_settings(cls, values: Dict[str, object]) -> "FormatOptions":
        """Options from ``format:`` settings (:data:`bibcc.config.FORMAT_SETTINGS`); unset keys keep defaults."""
        merged = {key: s.default for key, s in FORMAT_SETTINGS.items()}
        merged.update(values)
        indent = merged["indent"]
        return cls(
            sort_fields=bool(merged["sort_fields"]),
            field_order=tuple(merged["field_order"]) if merged["field_order"] is not None else tuple(FIELD_ORDER),
            sort_entries=bool(merged["sort_entries"]),
            braces=not merged["keep_quotes"],
            outer_braces=not merged["keep_outer_braces"],
            months=not merged["keep_months"],
            pages=not merged["keep_pages"],
            align=bool(merged["align"]),
            indent="\t" if indent == "tab" else " " * int(indent),
            blank_lines=int(merged["blank_lines"]),
            trailing_comma=bool(merged["trailing_comma"]),
            drop_empty=bool(merged["drop_empty"]),
        )


@dataclass
class FormatResult:
    """Outcome of formatting one text."""

    text: str
    entries: int
    changed: List[str] = field(default_factory=list)  # keys of reformatted entries
    reordered: bool = False

    def describe(self) -> str:
        if self.changed:
            detail = f"{len(self.changed)} of {self.entries} entries reformatted"
        else:
            detail = f"spacing between entries only ({self.entries} entries unchanged)"
        if self.reordered:
            detail += ", entries sorted"
        return detail


@dataclass
class _Block:
    """Non-entry text (comments, @string, ...) preceding an entry."""

    lines: List[str]
    attached: bool  # no blank line between the block and the entry after it

    @property
    def hoisted(self) -> bool:
        return bool(_HOISTED_BLOCK.search("\n".join(self.lines)))


# ----------------------------------------------------------------- values


def _is_empty(raw: str) -> bool:
    tokens = value_tokens(raw)
    return len(tokens) == 1 and tokens[0][:1] in '{"' and not unwrap(tokens[0]).strip()


def _inner_group(text: str) -> Optional[str]:
    """The content of *text* if it is one brace group (``{...}``), else None.

    A group opening with a backslash (``{\\"o}``) is a BibTeX special
    character, which behaves differently once it loses its braces, so it does
    not count.
    """
    text = text.strip()
    if len(text) < 2 or text[0] != "{" or text[-1] != "}" or text.startswith("{\\"):
        return None
    depth = 0
    for i, ch in enumerate(text):
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and i < len(text) - 1:
                return None
    return text[1:-1] if depth == 0 else None


def _strip_outer(value: str) -> str:
    """*value* (the text inside the field's braces) without redundant brace pairs."""
    inner = _inner_group(value)
    while inner is not None:
        value = inner
        inner = _inner_group(value)
    return value


def _convert(name: str, raw: str, options: FormatOptions) -> str:
    """Return the formatted value text for field *name* with raw value *raw*."""
    tokens = value_tokens(raw)
    if len(tokens) != 1:
        return raw
    token = tokens[0]
    if options.braces and token.startswith('"') and balanced(unwrap(token)):
        token = "{" + unwrap(token) + "}"
    if options.outer_braces and name not in _NAME_FIELDS and token.startswith("{"):
        token = "{" + _strip_outer(token[1:-1]) + "}"
    if name == "month" and options.months:
        macro = month_macro(unwrap(token))
        if macro:
            return macro
    if name == "pages" and options.pages and token[:1] in '{"':
        token = token[0] + page_range(unwrap(token)) + token[-1]
    if options.braces and token.isascii() and token.isdigit():
        return "{" + token + "}"
    return token


# --------------------------------------------------------------- entries


def _render_entry(text: str, entry: EntrySpan, options: FormatOptions) -> str:
    fields: List[Tuple[str, str]] = []
    for span in entry.fields.values():
        raw = text[span.value_start : span.value_end]
        if options.drop_empty and _is_empty(raw):
            continue
        name = span.name.lower()
        fields.append((name, _convert(name, raw, options)))

    if options.sort_fields:
        rank: Dict[str, int] = {}
        others = len(options.field_order)
        for i, n in enumerate(options.field_order):
            if n == OTHER_FIELDS:
                others = i
            else:
                rank[n.lower()] = i
        # sorted() is stable, so unlisted fields keep their source order.
        fields.sort(key=lambda f: rank.get(f[0], others))

    width = max((len(n) for n, _ in fields), default=0) if options.align else 0
    lines = [f"@{entry.entry_type.lower()}{{{entry.key},"]
    for i, (name, value) in enumerate(fields):
        comma = "," if i < len(fields) - 1 or options.trailing_comma else ""
        lines.append(f"{options.indent}{name.ljust(width)} = {value}{comma}")
    lines.append("}")
    return "\n".join(lines)


# ------------------------------------------------------------ layout text


def _is_blank(line: str) -> bool:
    return not line.strip()


def _block(lines: List[str]) -> Optional[_Block]:
    """Build a block from the lines between two entries.

    The last element of *lines* is the text before ``@`` on the next entry's
    line, so a blank last element is not a blank line.
    """
    content = [i for i, line in enumerate(lines) if not _is_blank(line)]
    if not content:
        return None
    first, last = content[0], content[-1]
    trailing_blank = len(lines) - 1 - last - 1
    return _Block(lines[first : last + 1], attached=trailing_blank <= 0)


def _split_gap(gap: str) -> Tuple[str, List[str]]:
    """Split the text after an entry into its same-line remainder and next lines."""
    parts = gap.split("\n")
    if len(parts) == 1:
        return "", parts
    return parts[0].rstrip(), parts[1:]


def _split_head(block: _Block) -> Tuple[Optional[_Block], Optional[_Block]]:
    """Split the text above the first entry into a file header and the
    paragraph directly attached to that entry (which moves with it when sorting).

    Without a blank line the whole block is treated as a file header.
    """
    blanks = [i for i, line in enumerate(block.lines) if _is_blank(line)]
    if not blanks:
        return block, None
    tail = _Block(block.lines[blanks[-1] + 1 :], attached=True)
    if tail.hoisted:
        return block, None
    head_lines = block.lines[: blanks[-1]]
    while head_lines and _is_blank(head_lines[-1]):
        head_lines.pop()
    return _Block(head_lines, attached=False), tail


def _outside_lines(text: str, entries: List[EntrySpan]) -> List[str]:
    """Non-blank stripped lines of the text outside entries."""
    pieces, pos = [], 0
    for entry in entries:
        pieces.append(text[pos : entry.start])
        pos = entry.end
    pieces.append(text[pos:])
    return [line.strip() for piece in pieces for line in piece.split("\n") if line.strip()]


def _render(
    text: str, entries: List[EntrySpan], options: FormatOptions
) -> Tuple[str, List[str], bool]:
    """Format LF text whose entries are *entries*.

    Returns ``(text, keys of reformatted entries, whether entries moved)``.
    """
    # blocks[i] precedes entries[i]; blocks[0] is the text at the top of the file.
    blocks: List[Optional[_Block]] = [_block(text[: entries[0].start].split("\n"))]
    remainders: List[str] = []
    rendered: List[str] = []
    changed: List[str] = []
    trailer: Optional[_Block] = None
    for i, entry in enumerate(entries):
        new_entry = _render_entry(text, entry, options)
        if new_entry != text[entry.start : entry.end]:
            changed.append(entry.key)
        rendered.append(new_entry)
        last = i + 1 == len(entries)
        remainder, lines = _split_gap(text[entry.end : len(text) if last else entries[i + 1].start])
        remainders.append(remainder)
        if last:
            trailer = _block(lines + [""])
        else:
            blocks.append(_block(lines))

    head, blocks[0] = blocks[0], None
    if head is not None and options.sort_entries and head.attached:
        head, blocks[0] = _split_head(head)
    top: List[_Block] = [head] if head else []
    order = list(range(len(entries)))
    if options.sort_entries:
        # @string/@preamble definitions must stay above the entries using them.
        for i, b in enumerate(blocks):
            if b is not None and b.hoisted:
                top.append(b)
                blocks[i] = None
        order.sort(key=lambda i: entries[i].key.lower())

    sep = "\n" * (options.blank_lines + 1)
    out: List[str] = []
    for n, b in enumerate(top):
        out.append("\n".join(b.lines))
        out.append("\n" if n == len(top) - 1 and b.attached else sep)
    for n, i in enumerate(order):
        if n:
            out.append(sep)
        b = blocks[i]
        if b is not None:
            out.append("\n".join(b.lines))
            out.append("\n" if b.attached else sep)
        out.append(rendered[i] + remainders[i])
    if trailer is not None:
        out.append(sep)
        out.append("\n".join(trailer.lines))
    out.append("\n")
    return "".join(out), changed, order != sorted(order)


# ------------------------------------------------------------ verification


def _parse(text: str):
    parser = bibtexparser.bparser.BibTexParser(
        common_strings=True, ignore_nonstandard_types=False, interpolate_strings=False
    )
    try:
        return bibtexparser.loads(text, parser=parser)
    except Exception as e:  # pyparsing and bibtexparser raise assorted types
        raise BibEditError(f"bibtexparser cannot parse the file: {e}") from e


def _canon(value) -> object:
    if isinstance(value, BibDataStringExpression):
        return tuple(
            ("macro", part.name.lower()) if isinstance(part, BibDataString) else ("text", part)
            for part in value.expr
        )
    if isinstance(value, BibDataString):
        return (("macro", value.name.lower()),)
    return value


def _month_of(value) -> Optional[str]:
    canon = _canon(value)
    if isinstance(canon, tuple):
        return month_macro(canon[0][1]) if len(canon) == 1 else None
    return month_macro(canon)


def _with_commas(text: str, entries: List[EntrySpan]) -> str:
    """*text* with the commas that are missing after keys and between fields inserted.

    The scanner reads entries without them, but bibtexparser does not, so the
    input is repaired before it is parsed for comparison.
    """
    inserts: List[int] = []
    for entry in entries:
        spans = list(entry.fields.values())
        ends = [entry.key_end] + [f.value_end for f in spans[:-1]] if spans else []
        for pos in ends:
            rest = text[pos:entry.closer].lstrip()
            if not rest.startswith(","):
                inserts.append(pos)
    for pos in reversed(inserts):
        text = text[:pos] + "," + text[pos:]
    return text


def _verify(old: str, new: str, options: FormatOptions) -> None:
    """Raise BibEditError unless *new* holds the same bibliography as *old*."""
    old_spans, new_spans = scan(old), scan(new)
    old_keys = [e.key for e in old_spans]
    expected = sorted(old_keys, key=str.lower) if options.sort_entries else old_keys
    if [e.key for e in new_spans] != expected:
        raise BibEditError("formatting changed the sequence of citation keys")

    old_lines, new_lines = _outside_lines(old, old_spans), _outside_lines(new, new_spans)
    if options.sort_entries:
        old_lines, new_lines = sorted(old_lines), sorted(new_lines)
    if old_lines != new_lines:
        raise BibEditError("formatting changed the text between entries")

    # bibtexparser skips entries without fields (bibcc add's empty entries); compare the others.
    empty = {e.key for e in old_spans if not e.fields}
    if empty != {e.key for e in new_spans if not e.fields}:
        raise BibEditError("formatting changed which entries have no fields")
    old_db, new_db = _parse(_with_commas(old, old_spans)), _parse(new)
    for label, db, keys in (
        ("input", old_db, [k for k in old_keys if k not in empty]),
        ("output", new_db, [k for k in expected if k not in empty]),
    ):
        parsed = [e["ID"] for e in db.entries]
        if sorted(parsed) != sorted(keys):
            missing = sorted(set(keys) - set(parsed)) or sorted(set(parsed) - set(keys))
            raise BibEditError(f"bibtexparser does not read entry '{missing[0]}' of the {label}")
    if {k: _canon(v) for k, v in old_db.strings.items()} != {
        k: _canon(v) for k, v in new_db.strings.items()
    } or old_db.preambles != new_db.preambles:
        raise BibEditError("formatting changed @string or @preamble definitions")

    new_by_key = {e["ID"]: e for e in new_db.entries}
    for old_entry in old_db.entries:
        key = old_entry["ID"]
        new_entry = new_by_key[key]
        if old_entry["ENTRYTYPE"].lower() != new_entry["ENTRYTYPE"].lower():
            raise BibEditError(f"formatting changed the type of '{key}'")
        for name in set(old_entry) | set(new_entry):
            if name in ("ID", "ENTRYTYPE"):
                continue
            if name not in new_entry:
                if options.drop_empty and _canon(old_entry[name]) == "":
                    continue
                raise BibEditError(f"formatting removed field '{name}' of '{key}'")
            if name not in old_entry:
                raise BibEditError(f"formatting added field '{name}' to '{key}'")
            old_value, new_value = old_entry[name], new_entry[name]
            if options.outer_braces and name not in _NAME_FIELDS and isinstance(old_value, str):
                old_value = _strip_outer("{" + old_value + "}")
            if _canon(old_value) == _canon(new_value):
                continue
            if name == "month" and _month_of(old_value) and _month_of(old_value) == _month_of(new_value):
                continue
            if (
                name == "pages"
                and options.pages
                and isinstance(old_value, str)
                and page_range(old_value) == _canon(new_value)
            ):
                continue
            raise BibEditError(f"formatting changed field '{name}' of '{key}'")


# ---------------------------------------------------------------- public


def format_bib(text: str, options: Optional[FormatOptions] = None) -> FormatResult:
    """Format BibTeX *text*; the result is verified and idempotent.

    Raises:
        BibEditError: if the text cannot be scanned or parsed, has duplicate
            keys, or the formatted text fails verification.
    """
    options = options or FormatOptions()
    bom = _BOM if text.startswith(_BOM) else ""
    crlf = "\r\n" in text
    lf = text[len(bom) :].replace("\r\n", "\n")

    entries = scan(lf)
    if not entries:
        return FormatResult(text, 0)
    duplicates = [k for k, n in Counter(e.key for e in entries).items() if n > 1]
    if duplicates:
        raise BibEditError(f"duplicate citation key '{duplicates[0]}'")

    new_lf, changed, reordered = _render(lf, entries, options)
    _verify(lf, new_lf, options)
    again, _, _ = _render(new_lf, scan(new_lf), options)
    if again != new_lf:
        raise BibEditError("formatting is not idempotent for this file")

    new_text = bom + (new_lf.replace("\n", "\r\n") if crlf else new_lf)
    return FormatResult(new_text, len(entries), changed, reordered)


def format_text(text: str, options: Optional[FormatOptions] = None) -> str:
    """Return *text* formatted with *options* (see :func:`format_bib`)."""
    return format_bib(text, options).text


def collect_bib_files(paths: Sequence[str | Path]) -> Tuple[List[Path], List[str]]:
    """Expand files and directories (recursively) into .bib files.

    Returns ``(files, missing_paths)``; ``.bibcc/`` folders are skipped.
    """
    files: List[Path] = []
    missing: List[str] = []
    for raw in paths:
        path = Path(raw)
        if path.is_dir():
            found = (
                f
                for f in path.rglob("*.bib")
                if f.is_file() and OUTPUT_DIR_NAME not in f.relative_to(path).parts
            )
            files.extend(sorted(found))
        elif path.is_file():
            files.append(path)
        else:
            missing.append(str(raw))
    unique: List[Path] = []
    seen: Set[Path] = set()
    for f in files:
        if f.resolve() not in seen:
            seen.add(f.resolve())
            unique.append(f)
    return unique, missing


def format_paths(
    paths: Sequence[str | Path],
    options: FormatOptions | Callable[[Path], FormatOptions],
    *,
    in_place: bool = False,
    output: Optional[str | Path] = None,
    check: bool = False,
    log_dir: Optional[Path] = None,
    log: Optional[Callable[[str], None]] = None,
) -> Dict[str, list]:
    """Format every .bib file under *paths*.

    Without *in_place*, *output*, or *check* this is a dry run that writes a
    ``.bibcc/<file>/format.diff`` per changed file.  *check* writes nothing.
    *options* may be a function of the file, which picks each file's
    settings (from the config that applies to it).

    Returns ``{"changed": [path], "unchanged": [path], "failed": [(path, error)]}``.
    """
    log = log or print
    files, missing = collect_bib_files(paths)
    changed: List[str] = []
    unchanged: List[str] = []
    failed: List[Tuple[str, str]] = [(m, "no such file or directory") for m in missing]
    for m in missing:
        log(f"❌ {m}: no such file or directory")
    if output is not None and len(files) + len(missing) != 1:
        raise BibEditError("--output needs exactly one input file")

    for path in files:
        try:
            file_options = options(path) if callable(options) else options
            text = read_bib(path)
            result = format_bib(text, file_options)
        except (BibEditError, ConfigError, UnicodeDecodeError) as e:
            log(f"❌ {path}: {e} (skipped)")
            failed.append((str(path), str(e)))
            continue

        is_changed = result.text != text
        (changed if is_changed else unchanged).append(str(path))
        status = result.describe() if is_changed else f"already formatted ({result.entries} entries)"

        if check:
            log(f"{'✏️  would reformat' if is_changed else '✅'} {path}: {status}")
            continue
        if log_dir is None:
            migrate_legacy_reports(path)
        diff_path = report_dir(path, log_dir, create=False) / "format.diff"
        if output is not None:
            write_bib(output, result.text)
            remove_report(diff_path)
            log(f"✅ {path} → {output}: {status}")
        elif in_place:
            if is_changed:
                write_bib(path, result.text)
            remove_report(diff_path)
            log(f"✅ {path}: {status}")
        elif is_changed:
            diff_path.parent.mkdir(parents=True, exist_ok=True)
            diff_path.write_text(unified_diff(text, result.text, path), encoding="utf-8")
            log(f"✏️  {path}: {status}. Diff: {diff_path}")
        else:
            remove_report(diff_path)
            log(f"✅ {path}: {status}")

    log(SEPARATOR_THIN * SEPARATOR_WIDTH)
    verb = "would change" if check or not (in_place or output is not None) else "changed"
    log(f"{len(files)} file(s): {len(changed)} {verb}, {len(unchanged)} already formatted, "
        f"{len(failed)} failed.")
    if changed and not (check or in_place or output is not None):
        log("🧪 Dry run. To write the changes, run with --in-place or --output FILE.bib.")
    return {"changed": changed, "unchanged": unchanged, "failed": failed}


def _indent(value: str) -> int | str:
    try:
        return parse_indent(value)
    except ConfigError:
        raise argparse.ArgumentTypeError("use a number of spaces or 'tab'") from None


def _non_negative(value: str) -> int:
    if not value.isdigit():
        raise argparse.ArgumentTypeError("expected a non-negative integer")
    return int(value)


def _field_order(value: str) -> Tuple[str, ...]:
    try:
        return parse_field_order(value, "--field-order")
    except ConfigError as e:
        raise argparse.ArgumentTypeError(str(e)) from None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="""\
Reformat whole .bib files in one consistent style. Unlike the other commands,
which only touch the fields they change, format rewrites the layout of every
entry. The default style:

  @inproceedings{GKEAL_Zhuang_CVPR2023,
    title     = {{GKEAL}: {Gaussian} Kernel Embedded Analytic Learning ...},
    year      = {2023},
    month     = jun,
    booktitle = {2023 {IEEE/CVF} Conference on Computer Vision ...}
  }

- Lowercase entry types and field names, a two-space indent, and aligned '='.
- "..." values and bare numbers become {...}. The command keeps #
  concatenations and macros such as @string names.
- Values wrapped in extra braces get one pair ({{Title}} -> {Title}), except
  author and editor, where {{...}} keeps a corporate name together.
- A comma follows every field except the last; the command adds missing
  commas.
- Months become macros ({June}, "6", or Jun. -> jun).
- Page ranges use a double hyphen (12-15 -> 12--15).
- One blank line between entries, and one newline at the end of the file.
- The command keeps the field order (unless you sort fields), the values
  (including line breaks inside them), % comments, and @string, @comment,
  and @preamble blocks.

Each style option can also come from the format: section of a config file:
the user config ($BIBCC_CONFIG, or else ~/.config/bibcc/config.yaml) and the
nearest .bibcc.yaml in the directory of each .bib file or a parent
directory. The project's values win over the user's, and the options you pass
win over both. For the keys, and to start from a shared config, see
'bibcc config -h'.

The command parses every result again. The result must contain the same
entries, types, fields, and values, and formatting it a second time must
change nothing. The command reports and skips files that fail this check,
can't be parsed, or have duplicate keys. Without --in-place, --output, or
--check, the command does a dry run and writes one diff per changed file.""",
        epilog=epilog(
            examples=[
                ("Preview every .bib file in bib/ (writes diffs in .bibcc/)", "bibcc format bib/"),
                ("Format the files in place", "bibcc format bib/ --in-place"),
                ("Format one file into another", "bibcc format refs.bib --output tidy.bib"),
                ("In CI, fail if a file isn't formatted", "bibcc format bib/ --check"),
                ("Also sort fields and entries, and indent with tabs",
                 "bibcc format refs.bib --in-place --sort-fields --sort-entries --indent tab"),
                ("Sort fields, keeping citation last after every unlisted field",
                 "bibcc format bib/ --in-place --sort-fields --field-order 'title,author,year,*,citation'"),
                ("Ignore the config files for one run", "bibcc format bib/ --no-config"),
            ],
            outputs=[
                (".bibcc/FILE/format.diff", "Dry run: the changes for each changed file"),
                (".bibcc/PATH/logs/formatter.log", "Everything printed to the terminal (not written with --check)"),
            ],
            exit_status="0 on success, 1 if a file fails (or, with --check, would change),\n"
            "2 on usage errors.",
            env=[ENV_CONFIG],
        ),
        formatter_class=HelpFormatter,
    )
    parser.add_argument(
        "paths",
        nargs="+",
        metavar="PATH",
        help=".bib files or directories (searched recursively, skipping .bibcc/ directories).",
    )
    mode = parser.add_argument_group("what to write (pick one; default: dry run)").add_mutually_exclusive_group()
    mode.add_argument("--in-place", action="store_true", help="Write the formatted text back to each file.")
    mode.add_argument(
        "-o", "--output", default="", metavar="FILE", help="Write the formatted file to FILE (one input file only)."
    )
    mode.add_argument(
        "--check", action="store_true", help="Write nothing, and exit with status 1 if any file would change."
    )
    style = parser.add_argument_group(
        "style (each also a key of the format: config section; the --no- forms turn a config value off)"
    )
    flag = argparse.BooleanOptionalAction
    style.add_argument("--sort-fields", action=flag, default=None, help="Reorder fields using --field-order.")
    style.add_argument(
        "--field-order",
        type=_field_order,
        default=None,
        metavar="FIELDS",
        help=f"Comma-separated field order for --sort-fields. A {OTHER_FIELDS} marks where every unlisted "
        f"field goes, in source order (default: after the listed fields), so "
        f"'title,author,{OTHER_FIELDS},citation' keeps citation last "
        f"(default: {', '.join(FIELD_ORDER)}).",
    )
    style.add_argument(
        "--sort-entries",
        action=flag,
        default=None,
        help="Sort entries by citation key (case-insensitive). A comment directly before an "
        "entry moves with it; @string and @preamble blocks stay at the top.",
    )
    style.add_argument("--keep-quotes", action=flag, default=None,
                       help='Keep "..." values and bare numbers as they are.')
    style.add_argument(
        "--keep-outer-braces",
        action=flag,
        default=None,
        help="Keep values wrapped in extra braces ({{...}}) as they are.",
    )
    style.add_argument("--keep-months", action=flag, default=None,
                       help="Don't turn month values into macros (jun).")
    style.add_argument("--keep-pages", action=flag, default=None,
                       help="Don't turn page ranges such as 12-15 into 12--15.")
    style.add_argument("--align", action=flag, default=None,
                       help="Align '=' to the longest field name (default); --no-align writes 'name = value'.")
    style.add_argument(
        "--indent",
        type=_indent,
        default=None,
        metavar="N",
        help="Field indent: a number of spaces, or 'tab' (default: 2).",
    )
    style.add_argument(
        "--blank-lines",
        type=_non_negative,
        default=None,
        metavar="N",
        help="Blank lines between entries (default: 1).",
    )
    style.add_argument("--trailing-comma", action=flag, default=None, help="Put a comma after the last field.")
    style.add_argument("--drop-empty", action=flag, default=None,
                       help="Remove fields with empty values ({} or \"\").")
    settings = parser.add_argument_group("config files").add_mutually_exclusive_group()
    settings.add_argument(
        "--config",
        default="",
        metavar="FILE",
        help=f"Use only this config file instead of the user config ({USER_CONFIG_DISPLAY}) "
        f"and the project's {PROJECT_CONFIG_NAME}.",
    )
    settings.add_argument("--no-config", action="store_true",
                          help="Read no config file: use the built-in style and the options you pass.")
    parser.add_argument(
        "--log-dir",
        default="",
        metavar="DIR",
        help="Directory to use instead of .bibcc/ next to each input file; diffs go to DIR/FILE/.",
    )
    return parser


def _option_settings(args: argparse.Namespace) -> Dict[str, object]:
    """The format: settings given on the command line."""
    return {key: getattr(args, key) for key in FORMAT_SETTINGS if getattr(args, key, None) is not None}


def _settings_warnings(values: Dict[str, object]) -> List[str]:
    if "field_order" in values and not values.get("sort_fields"):
        return ["field_order has no effect without sort_fields (or --sort-fields)"]
    return []


def run(args: argparse.Namespace) -> None:
    parser = build_parser()
    files, missing = collect_bib_files(args.paths)
    if args.output and (len(args.paths) != 1 or len(files) != 1 or missing or Path(args.paths[0]).is_dir()):
        parser.error("--output needs exactly one input .bib file")
    given = _option_settings(args)
    fixed: Optional[Config] = None
    if args.config:
        try:
            fixed = load_config(args.config)
        except ConfigError as e:
            parser.error(str(e))
    log_dir = Path(args.log_dir) if args.log_dir else None
    first = Path(args.paths[0])

    with Logger("formatter", input_file=first, log_dir=log_dir, enabled=not args.check) as logger:
        for warning in field_order_warnings(given.get("field_order") or (), "--field-order"):
            logger.log(f"⚠️  {warning}")
        resolved: Dict[Tuple[str, ...], FormatOptions] = {}

        def options_for(path: Path) -> FormatOptions:
            config = fixed or load_config(start=path, use_files=not args.no_config)
            key = config.key()
            if key not in resolved:
                values = {**config.section(FORMAT_SECTION), **given}
                if config.present:
                    logger.log(f"⚙️  Format settings from {config.describe()}")
                for warning in config.warnings + _settings_warnings(values):
                    logger.log(f"⚠️  {warning}")
                resolved[key] = FormatOptions.from_settings(values)
            return resolved[key]

        summary = format_paths(
            args.paths,
            options_for,
            in_place=args.in_place,
            output=args.output or None,
            check=args.check,
            log_dir=log_dir,
            log=logger.log,
        )
    if summary["failed"] or (args.check and summary["changed"]):
        sys.exit(1)


if __name__ == "__main__":
    run(build_parser().parse_args())
