"""
Citation key legibility checker for BibTeX entries.

Validates that citation keys follow the ``METHOD_AUTHOR_VENUEYEAR`` convention
(e.g., ``PLAN_Wang_ICCV2025``, ``MG-CLIP_Huang_ICCV2025``).

The expected format is::

    {METHOD}_{AUTHOR}_{ABBREV}{YEAR}

where METHOD may contain alphanumeric characters, hyphens, and ``+``,
AUTHOR is alphabetic (optionally with ``'`` or ``-``), and ABBREV is a venue
abbreviation immediately followed by a four-digit year.

Usage:
    from bibcc.checkers.citation_keys import check_citation_keys

    rows = check_citation_keys("refs.bib", log=print)
"""

from __future__ import annotations

import re
import unicodedata
from typing import Callable, Dict, List, Optional, Set, Tuple

import bibtexparser

from bibcc.logging_utils import SEPARATOR_LIGHT, SEPARATOR_WIDTH

# Regex for expected citation key format: [PREFIX:]METHOD_AUTHOR_VENUEYEAR
# PREFIX: optional grouping label such as ``Survey:``
# METHOD: alphanumeric + hyphens + plus (at least 1 char)
# AUTHOR: alphabetic + apostrophe + hyphen (at least 1 char)
# VENUE: alphabetic abbreviation (at least 1 char; ``arXiv`` is lower-case)
# YEAR: exactly 4 digits
_KEY_PATTERN = re.compile(
    r"^(?:[A-Za-z]+:)?(?P<method>[A-Za-z0-9+\-]+)_(?P<author>[A-Za-z][A-Za-z'\-]*)"
    r"_(?P<venue>[A-Za-z]+)(?P<year>\d{4})$"
)

# ------------------------------------------------------------------ names

_NAME_PARTICLES = {"van", "von", "de", "der", "den", "di", "da", "del", "della", "du", "dos", "la", "le", "ter", "ten"}
_LATEX_LETTERS = re.compile(r"\\(ss|ae|AE|oe|OE|aa|AA|l|L|o|O|i|j)(?![A-Za-z])")
# \'e  \"{u}  {\^ o}: symbol accents, with or without braces around the letter.
_LATEX_SYMBOL_ACCENT = re.compile(r"\\['`^\"~=.]\s*(?:\{\s*([A-Za-z])\s*\}|([A-Za-z]))")
# \k{a}  \v S  \c{c}: letter accents, which need braces or a space before the letter.
_LATEX_LETTER_ACCENT = re.compile(r"\\[uvHckbdrt](?:\s*\{\s*([A-Za-z])\s*\}|\s+([A-Za-z]))")


def decode_latex_letters(text: str) -> str:
    """``Zaj\\k{a}c`` → ``Zajac``: LaTeX accents and special letters as their ASCII base letters.

    Braces are kept, so that name splitting still sees ``{...}`` groups.
    """
    text = _LATEX_LETTERS.sub(lambda m: {"ss": "ss", "aa": "a", "AA": "A"}.get(m.group(1), m.group(1)), text)
    text = _LATEX_SYMBOL_ACCENT.sub(lambda m: m.group(1) or m.group(2), text)
    return _LATEX_LETTER_ACCENT.sub(lambda m: m.group(1) or m.group(2), text)


def _ascii_name(text: str) -> str:
    text = re.sub(r"\\[a-zA-Z]+|\\.", "", decode_latex_letters(text))
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Za-z'\-]", "", text)


def first_author_surname(author: str) -> str:
    """Surname of the first author, ASCII-folded, particles joined (``vandeVen``)."""
    first = decode_latex_letters(re.split(r"\s+and\s+", author.strip())[0])
    if "," in first:
        surname = first.split(",")[0]
    else:
        tokens = first.split()
        if not tokens:
            return ""
        parts = [tokens[-1]]
        i = len(tokens) - 2
        while i >= 1 and tokens[i].lower() in _NAME_PARTICLES:
            parts.insert(0, tokens[i])
            i -= 1
        surname = "".join(parts)
    return _ascii_name(surname.replace(" ", "").replace("{", "").replace("}", ""))


# Known venue abbreviations mapped from common full names
# This is used to verify the VENUE part against the actual booktitle/journal
VENUE_ABBREVIATIONS: Dict[str, Set[str]] = {
    # Top-tier CV conferences
    "CVPR": {
        "cvpr",
        "ieee/cvf conference on computer vision and pattern recognition",
        # Also the CVF Open Access name from 2025 ("... Pattern Recognition Conference (CVPR)").
        "computer vision and pattern recognition",
    },
    "ICCV": {"iccv", "ieee/cvf international conference on computer vision"},
    "ECCV": {
        "eccv",
        "european conference on computer vision",
        "computer vision -- eccv",
    },
    # ML conferences
    "NeurIPS": {
        "neurips",
        "neural information processing systems",
        "advances in neural information processing systems",
    },
    "ICML": {"icml", "international conference on machine learning"},
    "ICLR": {"iclr", "international conference on learning representations"},
    "AAAI": {"aaai", "aaai conference on artificial intelligence"},
    # Multimedia
    "MM": {"acm multimedia", "acm international conference on multimedia"},
    # Web
    "WWW": {"www", "web conference", "acm on web conference"},
    # NLP
    "ACL": {
        "acl",
        "association for computational linguistics",
        "annual meeting of the association for computational linguistics",
    },
    "EMNLP": {"emnlp", "empirical methods in natural language processing"},
    "NAACL": {"naacl", "north american chapter"},
    # Data mining / KDD
    "KDD": {"kdd", "knowledge discovery and data mining", "sigkdd"},
    # Speech
    "Interspeech": {"interspeech"},
    # Journal abbreviations
    "TIP": {"ieee transactions on image processing"},
    "TPAMI": {"ieee transactions on pattern analysis and machine intelligence"},
    "TMM": {"ieee transactions on multimedia"},
    "TNNLS": {"ieee transactions on neural networks and learning systems"},
    "TCSVT": {"ieee transactions on circuits and systems for video technology"},
    "TGRS": {"ieee transactions on geoscience and remote sensing"},
    "TOMM": {"acm transactions on multimedia computing"},
    "TKDD": {"acm transactions on knowledge discovery from data"},
    "TKDE": {"ieee transactions on knowledge and data engineering"},
    "PR": {"pattern recognition"},
    "IJCV": {"international journal of computer vision"},
    "ESWA": {"expert systems with applications"},
    "ASOC": {"applied soft computing"},
    "IPM": {"information processing"},
    "NC": {"neurocomputing"},
    "INS": {"information sciences"},
    "KBS": {"knowledge-based systems"},
    "NEUNET": {"neural networks"},
    "AIR": {"artificial intelligence review"},
    "TMLR": {"transactions on machine learning research"},
    "NATCOMM": {"nature communications"},
    "IJFS": {"international journal of fuzzy systems"},
    "SP": {"signal processing"},
    "SPL": {"ieee signal processing letters"},
}


_ABBREVIATIONS_BY_LOWER: Dict[str, str] = {a.lower(): a for a in VENUE_ABBREVIATIONS}


def _keyword_in(keyword: str, text: str) -> bool:
    return re.search(rf"(?<!\w){re.escape(keyword)}(?!\w)", text) is not None


def abbreviate_venue(venue: Optional[str]) -> str:
    """Suggest the key abbreviation for a journal or booktitle.

    Uses the longest matching :data:`VENUE_ABBREVIATIONS` keyword, then a
    parenthesised acronym such as ``(CVPR)``, then the venue's initials.
    Returns ``""`` when *venue* is empty.
    """
    text = (venue or "").replace("{", "").replace("}", "").replace("\\&", "&")
    lower = " ".join(text.split()).lower()
    if not lower:
        return ""
    best, best_len = "", 0
    for abbrev, keywords in VENUE_ABBREVIATIONS.items():
        for keyword in keywords:
            if len(keyword) > best_len and _keyword_in(keyword, lower):
                best, best_len = abbrev, len(keyword)
    if best:
        return best
    acronym = re.search(r"\(([A-Z][A-Za-z]{1,9})\)", text)
    if acronym:
        return acronym.group(1)
    words = [w for w in re.findall(r"[A-Za-z]+", text) if w.lower() not in _VENUE_STOPWORDS]
    if len(words) == 1:
        return words[0]
    return "".join(w[0].upper() for w in words) or "Venue"


_VENUE_STOPWORDS = {"a", "an", "and", "for", "in", "of", "on", "the", "to", "with"}


def _match_venue_abbreviation(
    abbrev: str,
    booktitle: Optional[str],
    journal: Optional[str],
) -> Optional[str]:
    """Check if a venue abbreviation matches the actual booktitle or journal.

    Returns a mismatch reason string if there's a problem, or None if OK.
    """
    raw = booktitle or journal or ""
    venue_text = " ".join(raw.replace("{", "").replace("}", "").replace("\\&", "&").split()).lower()
    if not venue_text:
        return None  # Can't verify without venue info

    canonical = _ABBREVIATIONS_BY_LOWER.get(abbrev.lower())
    if canonical is None:
        return None  # Unknown abbreviation — can't verify

    venue_display = (booktitle or journal or "")[:60]
    if not any(_keyword_in(keyword, venue_text) for keyword in VENUE_ABBREVIATIONS[canonical]):
        return f"abbreviation '{abbrev}' does not match venue '{venue_display}'"
    if abbrev != canonical:
        return f"write '{canonical}' instead of '{abbrev}'"
    return None


def _author_issue(key_author: str, author: str) -> Optional[str]:
    """A mismatch reason when the key's AUTHOR part is not the first author's surname.

    Part of a compound surname is accepted (``Rocamora`` or ``Abad`` for
    ``Abad Rocamora``, ``Ven`` for ``van de Ven``).
    """
    expected = first_author_surname(author)
    if not expected or not author.strip():
        return None
    pieces = [p.lower() for p in re.findall(r"[A-Z]?[a-z]+|[A-Z]+(?![a-z])", re.sub(r"['\-]", " ", expected))]
    if not pieces:
        return None
    joined = {"".join(pieces[i:]) for i in range(len(pieces))} | {"".join(pieces[:i]) for i in range(1, len(pieces))}
    if re.sub(r"[^a-z]", "", key_author.lower()) in joined:
        return None
    return f"key author '{key_author}' but the first author's surname is '{expected}'"


_PREPRINT_TYPES = {"misc", "unpublished", "techreport", "online", "preprint"}
_PREPRINT_VENUE = re.compile(r"\b(arxiv|corr|preprint)\b", re.IGNORECASE)


def _key_year_ok(key_year: str, entry_year: str, entry: Dict[str, str]) -> bool:
    """Whether the key's year fits the entry.

    Keys carry the year of the event, which may differ from ``year``:

    * the venue names the event year (``Computer Vision -- ECCV 2024``, published 2025);
    * proceedings appear the year after the event (CoLLAs 2024, SenSys 2023), so an
      ``@inproceedings`` one year older than ``year`` is accepted unless its venue
      names another year;
    * a preprint keyed by the venue that accepted it (``..._AAAI2026`` for a 2025
      arXiv paper) may be keyed later than ``year``.
    """
    if key_year == entry_year:
        return True
    venue = entry.get("booktitle") or entry.get("journal") or ""
    venue_years = set(re.findall(r"(?<!\d)(?:19|20)\d\d(?!\d)", venue))
    if key_year in venue_years:
        return True
    if not (key_year.isdigit() and entry_year.isdigit()):
        return False
    entry_type = entry.get("ENTRYTYPE", "").lower()
    if entry_type == "inproceedings" and int(key_year) == int(entry_year) - 1 and not venue_years:
        return True
    preprint = (entry_type in _PREPRINT_TYPES and not venue) or bool(_PREPRINT_VENUE.search(venue))
    return preprint and int(key_year) > int(entry_year)


def check_citation_keys(
    input_path: str,
    log: Optional[Callable[[str], None]] = None,
) -> List[Tuple[str, str, str]]:
    """Check citation key legibility against METHOD_AUTHOR_VENUEYEAR convention.

    Args:
        input_path: Path to the BibTeX file.
        log: Optional logging callback; falls back to ``print``.

    Returns:
        List of ``(entry_id, issue_type, detail)`` tuples where issue_type is
        one of ``"format"``, ``"author_mismatch"``, ``"venue_mismatch"``, or
        ``"year_mismatch"``.
    """
    log = log or print
    log(f"🔑 Checking citation key legibility in {input_path}...\n")

    try:
        with open(input_path, "r", encoding="utf-8") as f:
            parser = bibtexparser.bparser.BibTexParser(common_strings=True)
            bib_db = bibtexparser.load(f, parser=parser)
    except FileNotFoundError:
        log(f"❌ Error: File '{input_path}' not found.")
        return []

    issues: List[Tuple[str, str, str]] = []

    log(f"{'ID':<45} | {'Issue':<18} | Detail")
    log(SEPARATOR_LIGHT * SEPARATOR_WIDTH)

    for entry in bib_db.entries:
        entry_id = entry.get("ID", "")
        match = _KEY_PATTERN.match(entry_id)

        if not match:
            detail = f"expected METHOD_AUTHOR_VENUEYEAR, got '{entry_id}'"
            log(f"{entry_id:<45} | {'format':<18} | {detail}")
            issues.append((entry_id, "format", detail))
            continue

        author_issue = _author_issue(match.group("author"), entry.get("author", ""))
        if author_issue:
            log(f"{entry_id:<45} | {'author_mismatch':<18} | {author_issue}")
            issues.append((entry_id, "author_mismatch", author_issue))

        # Validate year matches entry year
        key_year = match.group("year")
        entry_year = entry.get("year", "").strip()
        if entry_year and not _key_year_ok(key_year, entry_year, entry):
            detail = f"key year={key_year} but entry year={entry_year}"
            log(f"{entry_id:<45} | {'year_mismatch':<18} | {detail}")
            issues.append((entry_id, "year_mismatch", detail))

        # Validate venue abbreviation matches booktitle/journal
        abbrev = match.group("venue")
        booktitle = entry.get("booktitle")
        journal = entry.get("journal")
        venue_issue = _match_venue_abbreviation(abbrev, booktitle, journal)
        if venue_issue:
            log(f"{entry_id:<45} | {'venue_mismatch':<18} | {venue_issue}")
            issues.append((entry_id, "venue_mismatch", venue_issue))

    log(SEPARATOR_LIGHT * SEPARATOR_WIDTH)
    total = len(bib_db.entries)
    if not issues:
        log(f"✅ All {total} citation keys follow the convention.")
    else:
        format_count = sum(1 for _, t, _ in issues if t == "format")
        author_count = sum(1 for _, t, _ in issues if t == "author_mismatch")
        venue_count = sum(1 for _, t, _ in issues if t == "venue_mismatch")
        year_count = sum(1 for _, t, _ in issues if t == "year_mismatch")
        parts = []
        if format_count:
            parts.append(f"format: {format_count}")
        if author_count:
            parts.append(f"author mismatch: {author_count}")
        if venue_count:
            parts.append(f"venue mismatch: {venue_count}")
        if year_count:
            parts.append(f"year mismatch: {year_count}")
        log(
            f"⚠️  Found {len(issues)} issues in {total} entries. Breakdown -> {'; '.join(parts)}"
        )

    return issues
